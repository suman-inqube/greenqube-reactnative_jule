import {
  StyleSheet,
  StatusBar,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Image,
  Modal,
  Alert,
} from 'react-native';
import React, { useEffect, useState, useRef, useCallback } from 'react';
import Logo from './Common/Logo';
import ButtonForm from './Common/ButtonForm';
import { useNavigation, useRoute } from '@react-navigation/native';
import InputTextForm from './Common/InputTextForm';
import DropdownForm from './Common/DropdownForm';
import config from '../config';
import axios from 'axios';
import ImageForm from './Common/ImageForm';
import DatePicker from 'react-native-date-picker';
import { getItem, setItem, removeItem } from '../config/getDataFromStorage';
import { isNotEmpty } from './Common/ValidationFunctions';
import MessageDialog from './Common/MessageDialog';
import { useFocusEffect } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';
import { CrashlyticsRecordError } from './Crashlytics/CrashlyticsRecordError';
import DeviceInfo from './DeviceInfo';
import { Root, Toast } from '@sekizlipenguen/react-native-popup-confirm-toast';
import { AlertMesg } from './Common/ToastAlert';
import Map from './admin/Map';
import * as geolib from 'geolib';
import { Colors, Fonts } from './utils/Constants';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import { getActionsMapView } from './utils/options';
import FloatingActionButton from './Components/FloatingActionButton';
import {
  convertedArrayLatLong,
  calculateAreaFun,
  calculatePolygonArea,
} from './Common/calculateAreaFun';
import DocumentPicker, { types } from '@react-native-documents/picker';
import ProofAndIdentityPropfComp from './Common/ProofAndIdentityPropfComp';
import {
  LandUnitArea,
  LandUnitsquare_metre,
  nearestLatLong,
} from '../config/apiHere';
import * as turf from '@turf/turf';
import { ROUTES } from './utils/Routes';
import { axiosGet } from './utils/api';
import { SafeAreaView, SafeAreaProvider } from 'react-native-safe-area-context';
import { formatISODateWithSuffix } from './Common/CommonFunction';
const ProduceInfoUpdate = () => {
  const { netConnection } = DeviceInfo();
  const { t } = useTranslation();
  const route = useRoute();
  const { pagename, arrayIndex } = route.params;
  const navigation = useNavigation();
  const [dbName, setdbName] = useState();
  const [lanID, setlanID] = useState();
  const [isLoading, setIsLoading] = useState(false);
  const [storeProduceInfoInArray, setstoreProduceInfoInArray] = useState([]);
  const [storeProduceInfo, setstoreProduceInfo] = useState({
    plotSiteName: '',
    daagNo: '',
    khatianNo: '',
    noOfPlants: '',
    jl_no: '',
    mouja: '',
    terrainType: '',
    landType: '',
    soilType: '',
    plotSize: '',
    landUnit: '',
    landUnitName: '',
    landUnitSize: '',
    prodctionSeasion: '',
    livelihoodType: '',
    produceName: '',
    produceVariety: '',
    productionProcess: '',
    expectedProduction: '',
    produceProductionUnit: '',
    cycleStarts: '',
    cycleEnds: '',
    lat: '',
    long: '',
    google_area: '',
    IOTId: '',
    IOTLatLong: '',
    IOTLatlat: '',
    ConvertedreportedLandsize: 0,
    is_id_proof: []
  });
  const [carbonOption, setcarbonOption] = useState("")
  const [landProof, setLandProof] = useState([
    { uri: '', name: '', type: '', fileName: '' },
    { uri: '', name: '', type: '', fileName: '' },
    { uri: '', name: '', type: '', fileName: '' },
    { uri: '', name: '', type: '', fileName: '' },
    { uri: '', name: '', type: '', fileName: '' },
    { uri: '', name: '', type: '', fileName: '' },
  ]);
  const [newdate, setnewDate] = useState(new Date());
  const [opencycleStarts, setOpencycleStarts] = useState(false);
  const [opencycleEnds, setOpencycleEnds] = useState(false);
  const [terrainTypeData, setterrainTypeData] = useState([]);
  const [landTypeData, setlandTypeData] = useState([]);
  const [soilTypeData, setsoilTypeData] = useState([]);
  const [landUnitData, setlandUnitData] = useState([]);
  const [prodctionSeasionData, setprodctionSeasionData] = useState([]);
  const [livelihoodTypeData, setlivelihoodTypeData] = useState([]);
  const [produceNameData, setproduceNameData] = useState([]);
  const [produceVarietyData, setproduceVarietyData] = useState([]);
  const [productionProcessData, setproductionProcessData] = useState([]);
  const [produceProductionUnitData, setproduceProductionUnitData] = useState(
    [],
  );
  const [location, setLocation] = useState([]);
  const [locationType, setLocationType] = useState('location_tap');
  const [landAreaUnit, setLandAreaUnit] = useState([]);
  const [landUnitsquareMetre, setLandUnitsquareMetre] = useState([]);
  const [nearPolSet, setnearPolSet] = useState([]);

  const [maxStartDate, setMaxStartDate] = useState(new Date());
  const [minStartDate, setMinStartDate] = useState(new Date());
  const [maxHarvestDate, setMaxHarvestDate] = useState(new Date());
  const [minHarvestDate, setMinHarvestDate] = useState(new Date());
  const [carbonFlag, setCarbonStatus] = useState(false);
  const renderLocationTags = () => {
    return location.map((data, index) => (
      <View key={index} style={styles.locationContainer}>
        <View style={styles.locationHeader}>
          <Text style={styles.locationTitle}>
            {t('location_point')} {index + 1}
          </Text>
          {data.latitude ? (
            <TouchableOpacity
              onPress={() =>
                locationType === 'location_tap' && handleCurrentLatLong(index)
              }
              style={styles.locationStatusActive}>
              <MaterialIcons name="check-circle" size={20} color="#4CAF50" />
              <Text style={styles.locationStatusText}>{t('captured')}</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              onPress={() =>
                locationType === 'location_tap' && handleCurrentLatLong(index)
              }
              style={styles.locationStatusInactive}>
              <MaterialIcons name="location-on" size={20} color="#F44336" />
              <Text style={styles.locationStatusText}>{t('tap_to_tag')}</Text>
            </TouchableOpacity>
          )}
        </View>

        {data.latitude ? (
          <View style={styles.coordinatesContainer}>
            <View style={styles.coordinateItem}>
              <MaterialIcons name="pin-drop" size={16} color="#2196F3" />
              <Text style={styles.coordinateText}>
                {t('lat')}: {parseFloat(data.latitude).toFixed(7)}
              </Text>
            </View>
            <View style={styles.coordinateItem}>
              <MaterialIcons name="pin-drop" size={16} color="#2196F3" />
              <Text style={styles.coordinateText}>
                {t('long')}: {parseFloat(data.longitude).toFixed(7)}
              </Text>
            </View>
          </View>
        ) : (
          <View style={styles.coordinatesContainer}>
            <View style={styles.coordinatePlaceholder}>
              <Text style={styles.placeholderText}>
                {t('not_captured_yet')}
              </Text>
            </View>
          </View>
        )}
      </View>
    ));
  };
  const groupByRelId = data => {
    const grouped = data.reduce((result, item) => {
      const newItem = {
        latitude: parseFloat(item.latitude),
        longitude: parseFloat(item.longitude),
      };

      if (!result[item.rel_id]) {
        result[item.rel_id] = [];
      }
      result[item.rel_id].push(newItem);
      return result;
    }, {});
    return Object.values(grouped);
  };
  const allAPIHere = async (dbname, language_id, produceName) => {
    const axiosConfig = {
      headers: {
        information: `${dbname},${language_id}`,
        Accept: 'application/json',
      },
    };
    const axiosConfig1 = {
      headers: {
        information: `${dbname},${language_id}`,
        Accept: 'application/json',
      },
    };
    const prodctionSeasionAPI =
      config.prodctionSeasionAPI1 + language_id + config.prodctionSeasionAPI2;
    var soilTypeArray = [];
    var terraintypeArray = [];
    var landTypeArray = [];
    var livelihoodTypeArray = [];
    var prodctionSeasionArray = [];
    var landUnitArray = [];
    var productionProcessArray = [];
    var produceProductionUnitArray = [];
    try {
      if (netConnection) {
        const [
          soilType_res,
          terraintype_res,
          landType_res,
          livelihoodType_res,
          prodctionSeasion_res,
          landUnit_res,
          productionProcess_res,
          produceProductionUnit_res,
        ] = await Promise.all([
          axios.get(config.soiltypeAPI, axiosConfig),
          axios.get(config.terraintypeAPI, axiosConfig),
          axios.get(config.landtypeAPI, axiosConfig),
          axios.get(prodctionSeasionAPI, axiosConfig1),
          // axios.get(prodctionSeasionAPI, axiosConfig1),
          axiosGet(
            ROUTES.GET.PRODUCE_SEASON({
              crop_name_fid: produceName.value,
              sd_id: '',
            }),
            '',
            {
              information: `${dbName},${lanID}`,
            },
          ),
          axios.get(config.landunitAPI, axiosConfig),
          axios.get(config.productionProcessAPI, axiosConfig),
          axios.get(config.produceProductionUnitAPI, axiosConfig),
        ]);

        if (soilType_res.data.data.count > 0) {
          soilType_res.data.data.rows.forEach(element => {
            soilTypeArray.push({
              value: element.id,
              label: element.name,
            });
          });
        }
        if (terraintype_res.data.data.count > 0) {
          terraintype_res.data.data.rows.forEach(element => {
            terraintypeArray.push({
              value: element.id,
              label: element.name,
            });
          });
        }
        if (landType_res.data.data.count > 0) {
          landType_res.data.data.rows.forEach(element => {
            landTypeArray.push({
              value: element.id,
              label: element.name,
            });
          });
        }
        if (livelihoodType_res.data.data) {
          livelihoodType_res.data.data.crop_type.forEach(element => {
            livelihoodTypeArray.push({
              value: element.fid,
              label: element.name,
            });
          });
        }

        if (prodctionSeasion_res.data.data) {
          prodctionSeasionArray = prodctionSeasion_res?.data?.data?.rows?.map(
            data => ({
              value: data.season_info.fid,
              label: `${data.season_info.name} (${data.year})`,
              sd_id: data.sd_id, // NEW FIELD - stores season detail ID
              year: data.year,
              originalName: data.season_info.name,
            }),
          );
        }
        if (landUnit_res.data.data.count > 0) {
          landUnit_res.data.data.rows.forEach(element => {
            landUnitArray.push({
              value: element.id,
              label: element.name,
              sizevalue: element.unit_value,
            });
          });
        }
        if (productionProcess_res.data.data.count > 0) {
          productionProcess_res.data.data.rows.forEach(element => {
            productionProcessArray.push({
              value: element.fid,
              label: element.name,
            });
          });
        }
        if (produceProductionUnit_res.data.data) {
          produceProductionUnit_res.data.data.rows.forEach(element => {
            produceProductionUnitArray.push({
              value: element.fid,
              label: element.unit_name,
            });
          });
        }
      } else {
        [
          soilTypeArray,
          terraintypeArray,
          landTypeArray,
          livelihoodTypeArray,
          prodctionSeasionArray,
          landUnitArray,
          productionProcessArray,
          produceProductionUnitArray,
        ] = await Promise.all([
          getItem('soilType_res'),
          getItem('terraintype_res'),
          getItem('landType_res'),
          getItem('livelihoodType_res'),
          getItem('prodctionSeasion_res'),
          getItem('landUnit_res'),
          getItem('productionProcess_res'),
          getItem('produceProductionUnit_res'),
        ]);
      }
      setlandUnitData(landUnitArray);
      setsoilTypeData(soilTypeArray);
      setterrainTypeData(terraintypeArray);
      setlandTypeData(landTypeArray);
      setlivelihoodTypeData(livelihoodTypeArray);
      setprodctionSeasionData(prodctionSeasionArray);
      setproductionProcessData(productionProcessArray);
      setproduceProductionUnitData(produceProductionUnitArray);
    } catch (error) {
      console.error(error);
      CrashlyticsRecordError(error.response);
    }
  };

  const HandlelivehoodType = async livelihoodType => {
    setstoreProduceInfo({ ...storeProduceInfo, livelihoodType: livelihoodType });
    produceNameDataList(livelihoodType, lanID, dbName);
  };

  const produceNameDataList = async (livelihoodType, language_id, dbName) => {
    const axiosConfig1 = {
      headers: {
        information: `${dbName},${language_id}`,
        Accept: 'application/json',
      },
    };
    try {
      let produceNameArray = [];
      let produceName_offline_list_arr = [];
      let produceName_offline_list = await getItem('produceName_res');
      const produceNameAPI =
        config.produceNameAPI1 +
        language_id +
        config.produceNameAPI2 +
        livelihoodType.value +
        config.produceNameAPI3;
      if (netConnection) {
        let produceName_res = await axios.get(produceNameAPI, axiosConfig1);
        if (produceName_res.data.data) {
          produceName_res.data.data.crop_name.forEach(element => {
            produceNameArray.push({
              value: element.crop_name.fid,
              label: element.crop_name.name,
            });
          });
          if (
            produceName_offline_list != null &&
            produceName_offline_list.length > 0
          ) {
            if (
              produceName_offline_list[0][livelihoodType.value] != undefined
            ) {
              JSON.parse(
                produceName_offline_list[0][livelihoodType.value],
              ).push({
                [livelihoodType.value]: JSON.stringify(produceNameArray),
              });
            } else {
              produceName_offline_list.push({
                [livelihoodType.value]: JSON.stringify(produceNameArray),
              });
            }
          } else {
            produceName_offline_list_arr.push({
              [livelihoodType.value]: JSON.stringify(produceNameArray),
            });
            produceName_offline_list = produceName_offline_list_arr;
          }
          await setItem('produceName_res', produceName_offline_list);
        }
      } else {
        if (produceName_offline_list) {
          produceName_offline_list_arr = produceName_offline_list.filter(
            function (v, i) {
              return (
                produceName_offline_list[i][livelihoodType.value] != undefined
              );
            },
          );
          if (produceName_offline_list_arr.length != 0) {
            produceNameArray = JSON.parse(
              produceName_offline_list_arr[0][livelihoodType.value],
            );
          } else {
            produceNameArray = [];
          }
        }
      }
      setproduceNameData(produceNameArray);
    } catch (error) {
      CrashlyticsRecordError(error.response);
      console.log('Error in produceName API', error);
    }
  };

  const handelChangeAddCrop = useCallback(
    async item => {
      setstoreProduceInfo(prev => ({
        ...prev,
        prodctionSeasion: item,
        prodctionSeasionSdId: item.sd_id,
        prodctionSeasionValue: item.value,
        cycleEnds: '',
        cycleStarts: '',
        // livelihoodType: '',
        // livelihoodTypeValue: '',
        // produceName: '',
        // produceNameValue: '',
        // produceVariety: '',
        // produceVarietyValue: '',
      }));
      console.log('fate==');
      const seasonData = await axiosGet(
        ROUTES.GET.PRODUCE_SEASON({
          // crop_name_fid: item.value,
          crop_name_fid: storeProduceInfo.produceName.value,
          sd_id: item.sd_id,
        }),
        '',
        {
          information: `${dbName},${lanID}`,
          // Authorization: `${token}`,
        },
      );
      console.log('frdate==', JSON.stringify(seasonData?.data?.data?.rows));
      if (seasonData?.data?.data?.rows?.length > 0) {
        const row = seasonData?.data?.data?.rows[0];

        setMinStartDate(row?.start_date ? new Date(row.start_date) : null);
        setMaxStartDate(row?.end_date ? new Date(row.end_date) : null);
        setMinHarvestDate(
          row?.harvest_sdate ? new Date(row.harvest_sdate) : null,
        );
        setMaxHarvestDate(
          row?.harvest_edate ? new Date(row.harvest_edate) : null,
        );
      }
    },
    [storeProduceInfo.produceName.value],
  );

  const HandleproduceName = async produceName => {
    setstoreProduceInfo({
      ...storeProduceInfo,
      produceName: produceName,
      prodctionSeasion: '',
      prodctionSeasionSdId: '',
      prodctionSeasionValue: '',
      cycleEnds: '',
      cycleStarts: '',
    });

    const seasonData = await axiosGet(
      ROUTES.GET.PRODUCE_SEASON({
        crop_name_fid: produceName.value,
        sd_id: '',
      }),
      '',
      {
        information: `${dbName},${lanID}`,
      },
    );
    if (seasonData?.status === 200) {
      // const seasonDataArr = seasonData?.data?.data?.rows?.map(data => ({
      //   value: data.season_info.fid,
      //   label: `${data.season_info.name} (${data.year})`,
      //   sd_id: data.sd_id,
      // }));
      const seasonDataArr = seasonData?.data?.data?.rows?.map(data => ({
        value: data.season_info.fid,
        label: `${data.season_info.name} (${data.year})`,
        sd_id: data.sd_id, // NEW FIELD - stores season detail ID
        year: data.year,
        originalName: data.season_info.name,
      }));
      setprodctionSeasionData(seasonDataArr);
    } else {
      setprodctionSeasionData([]);
      Toast.show({
        text: seasonData?.data?.error?.errorMessage,
        ...AlertMesg[0],
      });
    }
    produceVarientyDataList(produceName, lanID, dbName);
  };

  const produceVarientyDataList = async (produceName, language_id, dbName) => {
    const axiosConfig1 = {
      headers: {
        information: `${dbName},${language_id}`,
        Accept: 'application/json',
      },
    };
    try {
      const produceVarietyAPI =
        config.produceVarietyAPI1 +
        language_id +
        config.produceVarietyAPI2 +
        storeProduceInfo.livelihoodType +
        config.produceVarietyAPI3 +
        produceName.value;
      let produceVarietyArray = [];
      let produceVariety_offline_list_arr = [];
      let produceVariety_offline_list = await getItem('produceVariety_res');
      if (netConnection) {
        let produceVariety_res = await axios.get(
          produceVarietyAPI,
          axiosConfig1,
        );
        if (produceVariety_res.data.data) {
          produceVariety_res.data.data.crop_variety.forEach(element => {
            produceVarietyArray.push({
              value: element.crop_variety.fid,
              label: element.crop_variety.name,
            });
          });
          if (
            produceVariety_offline_list != null &&
            produceVariety_offline_list.length > 0
          ) {
            if (
              produceVariety_offline_list[0][produceName.value] != undefined
            ) {
              JSON.parse(
                produceVariety_offline_list[0][produceName.value],
              ).push({
                [produceName.value]: JSON.stringify(produceVarietyArray),
              });
            } else {
              produceVariety_offline_list.push({
                [produceName.value]: JSON.stringify(produceVarietyArray),
              });
            }
          } else {
            produceVariety_offline_list_arr.push({
              [produceName.value]: JSON.stringify(produceVarietyArray),
            });
            produceVariety_offline_list = produceVariety_offline_list_arr;
          }
          await setItem('produceVariety_res', produceVariety_offline_list);
        }
      } else {
        if (produceVariety_offline_list) {
          produceVariety_offline_list_arr = produceVariety_offline_list.filter(
            function (v, i) {
              return (
                produceVariety_offline_list[i][produceName.value] != undefined
              );
            },
          );
          if (produceVariety_offline_list_arr.length != 0) {
            produceVarietyArray = JSON.parse(
              produceVariety_offline_list_arr[0][produceName.value],
            );
          } else {
            produceVarietyArray = [];
          }
        }
      }
      setproduceVarietyData(produceVarietyArray);
    } catch (error) {
      CrashlyticsRecordError(error.response);
      console.log('Error in produceVariety API', error);
    }
  };

  const handlecycleStart = async item => {
    try {
      const dt = new Date(item);
      const x = dt.toISOString().split('T');
      const x1 = x[0].split('-');
      const cycleStarts = x1[0] + '-' + x1[1] + '-' + x1[2];
      setstoreProduceInfo({
        ...storeProduceInfo,
        cycleStarts: cycleStarts,
      });

    } catch (error) {
      console.error(error);
    }
  };

  const handlecycleEnd = async item => {
    const dt = new Date(item);
    const x = dt.toISOString().split('T');
    const x1 = x[0].split('-');
    const cycleEnds = x1[0] + '-' + x1[1] + '-' + x1[2];
    setstoreProduceInfo({ ...storeProduceInfo, cycleEnds: cycleEnds });
  };
  const handleLandUnit = async item => {
    let landUnitSize;
    if (item.sizevalue > 0) {
      landUnitSize = storeProduceInfo.plotSize * item.sizevalue;
    } else {
      landUnitSize = storeProduceInfo.plotSize * 1;
    }
    setstoreProduceInfo({
      ...storeProduceInfo,
      sizevalue: item.sizevalue,
      landUnit: item.value,
      landUnitSize: landUnitSize,
      landUnitName: item.label,
      ConvertedreportedLandsize:
        Number(item?.sizevalue) * Number(storeProduceInfo?.plotSize),
      // cycleEnds: ""
    });
  };

  const handleSave = async () => {


    //latest code 5%--
    if (area != null && area != undefined && area != '' && area != 0) {
      const reportedArea = storeProduceInfo?.ConvertedreportedLandsize;
      const googleArea = area;
      if (reportedArea < googleArea) {
        const deviation =
          (Math.abs(reportedArea - googleArea) /
            ((reportedArea + googleArea) / 2)) *
          100;
        if (deviation > 5) {
          // setstoreProduceInfo({ ...storeProduceInfo, cycleEnds: "" });
          Alert.alert(
            'Deviation',
            'The deviation between reported area and google area is not within 5%',
            [
              {
                text: 'OK',
                onPress: () =>
                  console.log(
                    'Area deviation (%) →',
                    deviation.toFixed(2),
                    '| Reported:',
                    reportedArea,
                    '| Google:',
                    googleArea,
                  ),
              },
            ],
            { cancelable: false },
          );
          return;
        }
      }
    }
    const locationEmpty = location.filter(item => item.latitude !== '');
    if (carbonFlag && carbonOption !== 'mangrove' && !storeProduceInfo.daagNo) {
      Toast.show({
        text: 'Please enter Daag Number',
        ...AlertMesg[0],
      });
      return;
    }
    if (carbonFlag && carbonOption !== 'mangrove' && !storeProduceInfo.jl_no) {
      Toast.show({
        text: 'Please enter JL Number',
        ...AlertMesg[0],
      });
      return;
    }
    if (storeProduceInfo.plotSize == '') {
      Toast.show({ time: 3, text: `${t('please_enter_unit')}`, ...AlertMesg[0] });
    } else if (carbonOption !== 'mangrove' && !storeProduceInfo.productionProcess.value) {
      Toast.show({
        time: 3,
        text: `${t('please_give_yeild_size')}`,
        ...AlertMesg[0],
      });
    } else if (storeProduceInfo.livelihoodType == '') {
      Toast.show({
        time: 3,
        text: `${t('please_select_crop_type_first')}`,
        ...AlertMesg[0],
      });
    } else if (storeProduceInfo.produceName == '') {
      Toast.show({
        time: 3,
        text: `${t('please_select_crop_name_first')}`,
        ...AlertMesg[0],
      });
    } else if (storeProduceInfo.produceVariety == '') {
      Toast.show({
        time: 3,
        text: `${t('please_select_crop_veriety_first')}`,
        ...AlertMesg[0],
      });
    } else if (locationEmpty == 0) {
      Toast.show({
        time: 3,
        text: `${t('please_submit_location_first')}`,
        ...AlertMesg[0],
      });
    } else {
      await removeItem('storeProduceInfo_data');
      storeProduceInfoInArray[arrayIndex].storeProduceInfo = storeProduceInfo;
      storeProduceInfoInArray[arrayIndex].location = location;
      await setItem('storeProduceInfo_data', storeProduceInfoInArray);
      navigation.navigate(pagename, { pagename: '' });
    }
  };

  const onPageLoad = async () => {
    const fusedLocation = await getItem('fusedLocation');
    const { latitude, longitude } = fusedLocation;
    let groupedData;
    const [
      storeSignup_data,
      storePersnolInfo_data,
      storeProduceInfo_data,
      produceVariety,
      carbonStatus,
      carbonOption
    ] = await Promise.all([
      getItem('storeSignup_data'),
      getItem('storePersnolInfo_data'),
      getItem('storeProduceInfo_data'),
      getItem('produceVariety'),
      getItem('carbon_status'),
      getItem('carbon_option'),
    ]);
    if (carbonOption) {
      setcarbonOption(carbonOption)
    }
    setCarbonStatus(carbonStatus);
    const dbName = storeSignup_data.company.dbname;
    const languageID = storePersnolInfo_data.language.value;
    setstoreProduceInfo(prev => ({
      ...prev,
      is_id_proof: storePersnolInfo_data?.identityProofIdentityPropf
    }));
    const [nearestLatLong_res, LandUnitArea_res, LandUnitsquare_metre_res] =
      await Promise.all([
        nearestLatLong(dbName, languageID, '', latitude, longitude),
        LandUnitArea(dbName, languageID),
        LandUnitsquare_metre(dbName, languageID),
      ]);

    if (nearestLatLong_res.status == 200) {
      groupedData = groupByRelId(nearestLatLong_res.data.data);
      //  console.log('groupedData', groupedData);
      setnearPolSet(groupByRelId(nearestLatLong_res.data.data));

      if (storeProduceInfo_data) {
        groupedData.push(storeProduceInfo_data[arrayIndex].location);
        setPolygons(groupedData);
      } else {
        setPolygons(groupedData);
      }
    }
    if (LandUnitArea_res?.status == 200) {
      const { count, rows } = LandUnitArea_res?.data?.data || {};
      if (count > 0) {
        setLandAreaUnit(rows);
      } else {
        setLandAreaUnit([]);
      }
    }
    if (LandUnitsquare_metre_res?.status == 200) {
      const { count, rows } = LandUnitsquare_metre_res?.data?.data || {};
      if (count > 0) {
        setLandUnitsquareMetre(rows);
      } else {
        setLandUnitsquareMetre([]);
      }
    }
    setdbName(dbName);
    setlanID(languageID);
    allAPIHere(
      dbName,
      languageID,
      storeProduceInfo_data[arrayIndex].storeProduceInfo.produceName,
    );
    const MIN_LAND_DOC = 5;

    const emptyLandDoc = () => ({
      uri: '',
      name: '',
      type: '',
      fileName: '',
      id: '',
    });

    const apiDocs = storeProduceInfo_data?.[arrayIndex]?.landProof || [];

    let updatedDocs = [...apiDocs];

    if (updatedDocs.length < MIN_LAND_DOC) {
      const emptyCount = MIN_LAND_DOC - updatedDocs.length;
      for (let i = 0; i < emptyCount; i++) {
        updatedDocs.push(emptyLandDoc());
      }
    }

    setLandProof(updatedDocs);
    let produceVarietyArray = [];
    if (produceVariety) {
      produceVariety.crop_variety.forEach(element => {
        produceVarietyArray.push({
          value: element.crop_variety.fid,
          label: element.crop_variety.name,
        });
      });
      setproduceVarietyData(produceVarietyArray);
    }
    if (storeProduceInfo_data) {
      setstoreProduceInfoInArray(storeProduceInfo_data);
      setLocation(storeProduceInfo_data[arrayIndex].location);

      // setArea(calculateAreaFun(storeProduceInfo_data[arrayIndex].location));
      // setNewPolygon(convertedArrayLatLong(storeProduceInfo_data[arrayIndex].location));
      if (storeProduceInfo_data[arrayIndex].location?.length >= 3) {
        // setArea(
        //   calculateAreaFun(storeProduceInfo_data[arrayIndex].location).toFixed(
        //     3,
        //   ),
        // );
        // if (landUnitsquareMetre?.[0]?.defined_unit_value) {
        setArea(
          storeProduceInfo_data[arrayIndex].storeProduceInfo
            .google_area_default,
        );
        // } else {
        //   setArea(calculateAreaFun(storeProduceInfo_data[arrayIndex].location));
        // }
      } else {
        setArea(0);
      }
      // setPolygons([
      //   storeProduceInfo_data[arrayIndex]?.location.filter(
      //     item => item.latitude !== '',
      //   ),
      // ]);
      setLocationType('api_lication');
      setstoreProduceInfo(storeProduceInfo_data[arrayIndex].storeProduceInfo);
      if (storeProduceInfo_data[arrayIndex].storeProduceInfo.livelihoodType) {
        produceNameDataList(
          storeProduceInfo_data[arrayIndex].storeProduceInfo.livelihoodType,
          languageID,
          dbName,
        );
        produceVarientyDataList(
          storeProduceInfo_data[arrayIndex].storeProduceInfo.produceName,
          languageID,
          dbName,
        );
      }
      if (
        storeProduceInfo_data[arrayIndex].storeProduceInfo.produceName &&
        storeProduceInfo_data[arrayIndex].storeProduceInfo.livelihoodType
      ) {
        produceVarientyDataList(
          storeProduceInfo_data[arrayIndex].storeProduceInfo.produceName,
          languageID,
          dbName,
        );
      }
      if (
        storeProduceInfo_data[arrayIndex].storeProduceInfo.maximumStartDate &&
        storeProduceInfo_data[arrayIndex].storeProduceInfo.prodctionSeasion
      ) {
        setMinStartDate(
          new Date(
            storeProduceInfo_data[arrayIndex].storeProduceInfo.minimumStartDate,
          ),
        );
        setMaxStartDate(
          new Date(
            storeProduceInfo_data[arrayIndex].storeProduceInfo.maximumStartDate,
          ),
        );
        setMinHarvestDate(
          new Date(
            storeProduceInfo_data[
              arrayIndex
            ].storeProduceInfo.minimumHarvestDate,
          ),
        );
        setMaxHarvestDate(
          new Date(
            storeProduceInfo_data[
              arrayIndex
            ].storeProduceInfo.maximumHarvestDate,
          ),
        );
        //  console.log('storeProduceInfo_data', storeProduceInfo_data);
      }
    }
  };

  useFocusEffect(
    React.useCallback(() => {
      onPageLoad();
    }, [netConnection]),
  );
  const handleCurrentLatLong = async index => {
    const fusedLocation = await getItem('fusedLocation');
    const values = [...location];
    const { latitude, longitude } = fusedLocation;
    if (
      fusedLocation != null &&
      longitude.toString().length == 10 &&
      latitude.toString().length == 10 &&
      latitude > 0 &&
      longitude > 0
    ) {
      values[index] = { latitude: latitude, longitude: longitude };
      setLocation(values);
      const filteredDatalatLong = values.filter(item => item.latitude !== '');
      setNewPolygon(convertedArrayLatLong(filteredDatalatLong));
      if (filteredDatalatLong.length >= 3) {
        // setArea(calculatePolygonArea(filteredDatalatLong).toFixed(3));
        if (landUnitsquareMetre?.[0]?.defined_unit_value) {
          setArea(
            Number(landUnitsquareMetre?.[0]?.defined_unit_value) *
            geolib.getAreaOfPolygon(filteredDatalatLong).toFixed(3),
          );
          setstoreProduceInfo({
            ...storeProduceInfo,
            google_area: geolib
              .getAreaOfPolygon(filteredDatalatLong)
              .toFixed(3),
            google_area_default:
              Number(landUnitsquareMetre?.[0]?.defined_unit_value) *
              geolib.getAreaOfPolygon(newPolygon),
          });
        } else {
          setArea(geolib.getAreaOfPolygon(filteredDatalatLong).toFixed(3));
          setstoreProduceInfo({
            ...storeProduceInfo,
            google_area: geolib
              .getAreaOfPolygon(filteredDatalatLong)
              .toFixed(3),
            google_area_default: geolib
              .getAreaOfPolygon(filteredDatalatLong)
              .toFixed(3),
          });
        }
      } else {
        setArea(0);
      }
    } else {
      Toast.show({
        text: t('Please_try_again_to_reach_the_accurancy'),
        ...AlertMesg[0],
      });
    }
  };

  const addMoreLocation = async () => {
    if (locationType != 'location_tap') {
      const locationLatLong = Array.apply(null, Array(location.length + 1)).map(
        (val, idx) => ({ latitude: '', longitude: '' }),
      );
      setLocation(locationLatLong);
      setLocationType('location_tap');
      setArea(0);
      setNewPolygon([]);
    } else {
      setNewPolygon([]);
      setLocation([...location, { latitude: '', longitude: '' }]);
    }
  };
  // GRQ-1130
  const [polygons, setPolygons] = useState([]);
  const [newPolygon, setNewPolygon] = useState([]);
  const [editing, setEditing] = useState(false);
  const [area, setArea] = useState(0);
  const [showModal, setShowModal] = useState(false);
  const handleMapPress = event => {
    if (!editing) return;
    const { latitude, longitude } = event.nativeEvent.coordinate;
    setNewPolygon([...newPolygon, { latitude, longitude }]);
  };
  // GRQ-1132
  const finalizePolygon = () => {
    if (newPolygon.length > 2) {
      // setPolygons([...polygons, newPolygon]);
      // basudev
      setPolygons([...nearPolSet, newPolygon]);
      // setPolygons([newPolygon]);
      setNewPolygon([]);
      setLocation(newPolygon);
      setEditing(false);
      setShowModal(false);
      // setArea(calculateAreaFun(newPolygon));
      if (landUnitsquareMetre?.[0]?.defined_unit_value) {
        setArea(
          Number(landUnitsquareMetre?.[0]?.defined_unit_value) *
          geolib.getAreaOfPolygon(newPolygon),
        );
        setstoreProduceInfo({
          ...storeProduceInfo,
          google_area: geolib.getAreaOfPolygon(newPolygon),
          google_area_default:
            Number(landUnitsquareMetre?.[0]?.defined_unit_value) *
            geolib.getAreaOfPolygon(newPolygon),
        });
      } else {
        setArea(geolib.getAreaOfPolygon(newPolygon));
        setstoreProduceInfo({
          ...storeProduceInfo,
          google_area: geolib.getAreaOfPolygon(newPolygon),
          google_area_default: geolib.getAreaOfPolygon(newPolygon),
        });
      }
    } else {
      //  setArea(0);
      Alert.alert('Error', 'A polygon requires at least 3 points.');
    }
    setLocationType('polygon_tap');
  };
  const clearNewPolygon = () => {
    setstoreProduceInfo({ ...storeProduceInfo, google_area: 0 });
    setNewPolygon([]);
    setPolygons(nearPolSet);
    setArea(0);
    removesetLocation();
  };

  const undoMark = () => {
    try {
      const value = [...newPolygon];
      console.log('value');
      console.log(value);
      value.pop();
      setNewPolygon(value);
    } catch (error) {
      console.log(error);
    }
  };
  // GRQ-1130
  // GRQ-1135
  // onPress={() => data.latitude != 10 && data.latitude.length != "" ? "" : handleCurrentLatLong(index)}
  // GRQ-1135
  const removesetLocation = () => {
    setLocation([
      { latitude: '', longitude: '' },
      // {latitude: '', longitude: ''},
      // {latitude: '', longitude: ''},
    ]);
  };
  const handleDocumentSelection = async (data, index) => {
    try {
      const response = await DocumentPicker.pick({
        presentationStyle: 'fullScreen',
        type: [types.pdf, types.images],
      });
      const values = [...landProof];
      values[index]['uri'] = response[0].uri;
      values[index]['name'] = response[0].name;
      values[index]['type'] = response[0].type;
      values[index]['fileName'] = response[0].name;
      setLandProof(values);
    } catch (err) {
      console.error(err);
    }
  };
  const handleDocumentSelectionRemove = index => {
    try {
      const values = [...landProof];
      values[index]['uri'] = '';
      values[index]['name'] = '';
      values[index]['type'] = '';
      values[index]['fileName'] = '';
      setLandProof(values);
    } catch (error) {
      console.log(error);
    }
  };
  const handleCurrentLatLongIOT = async () => {
    const fusedLocation = await getItem('fusedLocation');
    const { latitude, longitude } = fusedLocation;
    setstoreProduceInfo({
      ...storeProduceInfo,
      IOTLatlat: latitude,
      IOTLatLong: longitude,
    });
  };
  const regionRef = useRef(null);
  const timeoutRef = useRef(null);
  const handleRegionChangeComplete = async newRegion => {
    const { latitude, longitude } = newRegion;
    regionRef.current = newRegion;
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    timeoutRef.current = setTimeout(async () => {
      const latestRegion = regionRef.current;
      setIsLoading(true);
      const isSameLat =
        Math.abs(latestRegion.latitude - newRegion.latitude) < 0.0001;
      const isSameLng =
        Math.abs(latestRegion.longitude - newRegion.longitude) < 0.0001;
      if (isSameLat && isSameLng) {
        try {
          const nearestLatLong_res = await nearestLatLong(
            dbName,
            lanID,
            '',
            latitude,
            longitude,
          );
          if (nearestLatLong_res?.status === 200) {
            const data = nearestLatLong_res?.data?.data;
            // setnearPolData(data);
            const groupedData = groupByRelId(data);
            setnearPolSet(groupedData);
            setPolygons(groupedData);
          }
        } catch (error) {
          console.error('Error fetching nearest polygon data:', error);
        } finally {
          setIsLoading(false);
        }
      } else {
        setIsLoading(false);
      }
    }, 3000);
  };
  return (
    <SafeAreaProvider>
      <SafeAreaView
        style={{ flex: 1, backgroundColor: '#1d3122' }}
        edges={['top', 'right', 'bottom', 'left']}>
        <Root>
          {/* <ForegroundLocationService /> */}
          <StatusBar barStyle="light-content" backgroundColor={'#003c04'} />
          <View style={styles.mainContainer}>
            <View
              style={{
                // height: 100,
                backgroundColor: Colors.green,
                borderBottomLeftRadius: 25,
                borderBottomRightRadius: 25,
                justifyContent: 'flex-end',
                paddingTop: 30,
              }}>
              <View style={styles.headersContainer}>
                <Text style={styles.headersTitle}>
                  {t('reg_land_crop_information')}
                </Text>
              </View>
            </View>
            <ScrollView>
              <View style={styles.formContainer}>
                {/* <Logo iheight={100} iwidth={100} /> */}
                <View style={styles.firatFormContainer}>
                  <View style={{ alignItems: 'center' }}>
                    <Image
                      source={require('../pages/Common/images/logo.png')}
                      style={styles.logo}
                    />
                  </View>
                  <View style={{ paddingHorizontal: 10 }}>
                    <InputTextForm
                      label={t('pre_plot_name')}
                      color="black"
                      onChangeText={item =>
                        setstoreProduceInfo({
                          ...storeProduceInfo,
                          plotSiteName: item,
                        })
                      }
                      value={storeProduceInfo.plotSiteName}
                    />
                    {
                      carbonOption !== 'mangrove' && (
                        <>
                          <InputTextForm
                            label={t('daag_no')}
                            onChangeText={item =>
                              setstoreProduceInfo({ ...storeProduceInfo, daagNo: item })
                            }
                            value={storeProduceInfo.daagNo}
                            required={carbonFlag === true}
                          />
                          <InputTextForm
                            label={t('khatian_no')}
                            onChangeText={item =>
                              setstoreProduceInfo({
                                ...storeProduceInfo,
                                khatianNo: item,
                              })
                            }
                            value={storeProduceInfo.khatianNo}
                          />


                        </>
                      )
                    }
                    {carbonFlag == true && carbonOption !== 'mangrove' ? (
                      <InputTextForm
                        label={t('JL No')}
                        onChangeText={item =>
                          setstoreProduceInfo({
                            ...storeProduceInfo,
                            jl_no: item,
                          })
                        }
                        value={storeProduceInfo.jl_no}
                        required={carbonFlag === true}
                      />
                    ) : (
                      <></>
                    )}
                    {carbonFlag == true ? (
                      <InputTextForm
                        label={t('Mouja Name')}
                        onChangeText={item =>
                          setstoreProduceInfo({
                            ...storeProduceInfo,
                            mouja: item,
                          })
                        }
                        value={storeProduceInfo.mouja}
                      />
                    ) : (
                      <></>
                    )}
                    <InputTextForm
                      label={t('no_of_plants')}
                      onChangeText={item =>
                        setstoreProduceInfo({
                          ...storeProduceInfo,
                          noOfPlants: item,
                        })
                      }
                      value={storeProduceInfo.noOfPlants}
                    />
                    <DropdownForm
                      label={t('addland_terrain_type')}
                      color="black"
                      data={terrainTypeData}
                      onChange={item =>
                        setstoreProduceInfo({
                          ...storeProduceInfo,
                          terrainType: item,
                        })
                      }
                      val={storeProduceInfo.terrainType.label}
                    />
                    <DropdownForm
                      label={t('addland_soil_type')}
                      color="black"
                      data={landTypeData}
                      onChange={item => {
                        setstoreProduceInfo({
                          ...storeProduceInfo,
                          landType: item,
                        });
                      }}
                      val={storeProduceInfo.landType.label}
                    />
                    <DropdownForm
                      label={t('select_soil_type')}
                      color="black"
                      data={soilTypeData}
                      onChange={item => {
                        setstoreProduceInfo({
                          ...storeProduceInfo,
                          soilType: item,
                        });
                      }}
                      val={storeProduceInfo.soilType.label}
                    />
                    <InputTextForm
                      label={t('addland_landsize')}
                      onChangeText={item =>
                        setstoreProduceInfo({
                          ...storeProduceInfo,
                          plotSize: item,
                          ConvertedreportedLandsize:
                            Number(storeProduceInfo?.sizevalue) * Number(item),
                          // , cycleEnds: ""
                        })
                      }
                      value={storeProduceInfo.plotSize}
                      keyboardType="number-pad"
                    />
                    <DropdownForm
                      label={t('addland_unit')}
                      color="black"
                      data={landUnitData}
                      onChange={item => handleLandUnit(item)}
                      val={storeProduceInfo.landUnitName}
                    />
                    {!isNaN(
                      Number(storeProduceInfo?.ConvertedreportedLandsize),
                    ) &&
                      storeProduceInfo?.ConvertedreportedLandsize !== 0 &&
                      area != null && (
                        <InputTextForm
                          label={
                            t('Converted reported Land size ') +
                            `${landAreaUnit?.[0]?.defined_unit_value
                              ? `(${landAreaUnit?.[0]?.unit_name})`
                              : '(Square meter)'
                            }`
                          }
                          value={storeProduceInfo?.ConvertedreportedLandsize?.toString()}
                          editable={false}
                        />
                      )}
                    {
                      carbonOption !== 'mangrove' && (
                        <>
                          <View style={{ marginTop: 10 }}>
                            <InputTextForm
                              label={t('Enter IOT Device Id')}
                              onChangeText={item =>
                                setstoreProduceInfo({
                                  ...storeProduceInfo,
                                  IOTId: item,
                                })
                              }
                              value={storeProduceInfo.IOTId}
                            />
                          </View>

                          <View style={styles.locationContainer}>
                            <View style={styles.locationHeader}>
                              <Text style={styles.locationTitle}>
                                {t('Geo tag IOT Device')}
                              </Text>

                              <TouchableOpacity
                                onPress={() => handleCurrentLatLongIOT()}
                                style={styles.locationStatusInactive}>
                                <MaterialIcons
                                  name="location-on"
                                  size={20}
                                  color="#F44336"
                                />
                                <Text style={styles.locationStatusText}>
                                  {t('tap_to_tag')}
                                </Text>
                              </TouchableOpacity>
                            </View>
                            <View style={styles.coordinatesContainer}>
                              <View style={styles.coordinateItem}>
                                <MaterialIcons
                                  name="pin-drop"
                                  size={16}
                                  color="#2196F3"
                                />
                                <Text style={styles.coordinateText}>
                                  {t('lat')}: {storeProduceInfo.IOTLatlat}
                                </Text>
                              </View>
                              <View style={styles.coordinateItem}>
                                <MaterialIcons
                                  name="pin-drop"
                                  size={16}
                                  color="#2196F3"
                                />
                                <Text style={styles.coordinateText}>
                                  {t('long')}:{storeProduceInfo.IOTLatLong}
                                </Text>
                              </View>
                            </View>
                          </View>
                        </>
                      )
                    }

                    {
                      carbonOption !== 'mangrove'(
                        <ProofAndIdentityPropfComp
                          identityProofIdentityPropf={landProof}
                          t={t}
                          title={t('address_proof')}
                          setStateValue={setLandProof}
                          stateValue={landProof}
                          disable={true}
                          InputTextFormEdit={true}
                          allowAddMore={true}
                          // photoDeletedValue={photoDeletedValue}
                          // setPhotoDeletedValue={setPhotoDeletedValue}
                          // loginUser_data={loginUser_data}
                          is_id_proof={storeProduceInfo?.is_id_proof}
                        />

                      )
                    }
                    {/* basudev  */}
                    {area != 0 && (
                      <InputTextForm
                        label={
                          t('Calculated Map Area ') +
                          '(' +
                          `${landAreaUnit?.[0]?.defined_unit_value
                            ? landAreaUnit?.[0]?.unit_name
                            : 'Square meter'
                          }` +
                          ')'
                        }
                        value={area.toString()}
                        editable={false}
                      />
                    )}
                    <View style={styles.labelContainer}>
                      <Text style={styles.sectionTitle}>
                        {t('plot_location_points')}
                      </Text>
                    </View>
                    {renderLocationTags()}

                    <DropdownForm
                      label={t('addcrop_croptype')}
                      color="black"
                      data={livelihoodTypeData}
                      onChange={item => HandlelivehoodType(item)}
                      val={storeProduceInfo.livelihoodType.label}
                    />
                    <DropdownForm
                      label={t('select_crop_name')}
                      color="black"
                      data={produceNameData}
                      onChange={item => HandleproduceName(item)}
                      val={storeProduceInfo.produceName.label}
                    />
                    <DropdownForm
                      label={t('select_crop_variety')}
                      color="black"
                      data={produceVarietyData}
                      onChange={item => {
                        setstoreProduceInfo({
                          ...storeProduceInfo,
                          produceVariety: item,
                        });
                      }}
                      val={storeProduceInfo.produceVariety.label}
                    />
                    <DropdownForm
                      label={t('production_system')}
                      color="black"
                      data={productionProcessData}
                      onChange={item => {
                        setstoreProduceInfo({
                          ...storeProduceInfo,
                          productionProcess: item,
                        });
                      }}
                      val={storeProduceInfo.productionProcess.label}
                    />
                    {
                      carbonOption !== 'mangrove' && (
                        <>
                          <InputTextForm
                            label={t('expected_yield')}
                            color="black"
                            onChangeText={item =>
                              setstoreProduceInfo({
                                ...storeProduceInfo,
                                expectedProduction: item,
                              })
                            }
                            value={storeProduceInfo.expectedProduction}
                          />
                          <DropdownForm
                            label={t('select_unit')}
                            color="black"
                            data={produceProductionUnitData}
                            onChange={item => {
                              setstoreProduceInfo({
                                ...storeProduceInfo,
                                produceProductionUnit: item,
                              });
                            }}
                            val={storeProduceInfo.produceProductionUnit.label}
                          />

                        </>
                      )
                    }

                    <View style={{ marginTop: 5 }}>
                      <DropdownForm
                        label={t('addcrop_cultivating_season')}
                        required={true}
                        data={prodctionSeasionData}
                        // onChange={item => {
                        //   setstoreProduceInfo({
                        //     ...storeProduceInfo,
                        //     prodctionSeasion: item,
                        //   });
                        // }}
                        onChange={handelChangeAddCrop}
                        val={storeProduceInfo.prodctionSeasion.label}
                      />
                    </View>
                    <View style={{ marginVertical: 10 }}>
                      <View
                        style={{
                          flexDirection: 'row',
                          alignItems: 'center',
                          marginBottom: 5,
                        }}>
                        <Text
                          style={{
                            marginBottom: 5,
                            marginLeft: 5,
                            fontFamily: 'Poppins-Regular',
                            fontSize: 15,
                            color: '#4e4e4e',
                          }}>
                          Cycle Starts
                        </Text>
                        <Text
                          style={{
                            color: 'red',
                            fontFamily: Fonts.Medium,
                            fontSize: 16,
                          }}>
                          *
                        </Text>
                      </View>
                      <View style={styles.passwordMainContainer}>
                        <View style={styles.passwordContainer}>
                          <Text
                            style={styles.inputTextStyle}
                            onPress={() => setOpencycleStarts(true)}>
                            {storeProduceInfo.cycleStarts}
                          </Text>
                          <TouchableOpacity
                            onPress={() => setOpencycleStarts(true)}>
                            <ImageForm
                              source={require('./Common/images/date.png')}
                              resizeMode="cover"
                              height={30}
                              width={30}
                            />
                          </TouchableOpacity>
                          <DatePicker
                            modal
                            mode="date"
                            open={opencycleStarts}
                            date={minStartDate}
                            onConfirm={item => {
                              handlecycleStart(item);
                              setOpencycleStarts(false);
                            }}
                            onCancel={() => {
                              setOpencycleStarts(false);
                            }}
                            minimumDate={minStartDate}
                            maximumDate={maxStartDate}
                            // title={`${minStartDate}`}
                            title={`Select Date Range from (${formatISODateWithSuffix(
                              minStartDate,
                            )} - ${formatISODateWithSuffix(maxStartDate)})`}
                          />
                        </View>
                      </View>
                    </View>

                    <View style={{ marginVertical: 10 }}>
                      <View
                        style={{
                          flexDirection: 'row',
                          alignItems: 'center',
                          marginBottom: 5,
                        }}>
                        <Text
                          style={{
                            marginBottom: 5,
                            marginLeft: 5,
                            fontFamily: 'Poppins-Regular',
                            fontSize: 15,
                            color: '#4e4e4e',
                          }}>
                          Cycle Ends
                        </Text>
                        <Text
                          style={{
                            color: 'red',
                            fontFamily: Fonts.Medium,
                            fontSize: 16,
                          }}>
                          *
                        </Text>
                      </View>
                      <View style={styles.passwordMainContainer}>
                        <View style={styles.passwordContainer}>
                          <Text
                            style={styles.inputTextStyle}
                            onPress={() => setOpencycleEnds(true)}>
                            {storeProduceInfo.cycleEnds}
                          </Text>
                          <TouchableOpacity
                            onPress={() => setOpencycleEnds(true)}>
                            <ImageForm
                              source={require('./Common/images/date.png')}
                              resizeMode="cover"
                              height={30}
                              width={30}
                            />
                          </TouchableOpacity>
                          <DatePicker
                            modal
                            mode="date"
                            open={opencycleEnds}
                            date={minHarvestDate}
                            minimumDate={minHarvestDate}
                            maximumDate={maxHarvestDate}
                            title={`Select Date Range from (${formatISODateWithSuffix(
                              minHarvestDate,
                            )} - ${formatISODateWithSuffix(maxHarvestDate)})`}
                            onConfirm={item => {
                              handlecycleEnd(item);
                              setOpencycleEnds(false);
                            }}
                            onCancel={() => {
                              setOpencycleEnds(false);
                            }}
                          />
                        </View>
                      </View>
                    </View>
                  </View>
                </View>
              </View>
            </ScrollView>

            {/* <TouchableOpacity
        style={styles.locationAddMoreContainer}
        onPress={() => addMoreLocation()}>
        <Text style={[styles.title, {color: '#FFF', marginRight: 20}]}>
          {t('AddLocation')}
        </Text>
      </TouchableOpacity> */}

            <FloatingActionButton
              position="right"
              actions={getActionsMapView(t, styles, Colors)}
              color={Colors.useGreen}
              onPressItem={() => setShowModal(!showModal)}
              showBackground={true}
              overlayColor="rgba(22, 17, 17, 0.35)"
              distanceToEdge={{ vertical: 80, horizontal: 25 }}
            />
            {/* <TouchableOpacity
          style={[styles.locationAddMoreContainer, {bottom: 250}]}
          onPress={() => setShowModal(!showModal)}>
          <Text style={[styles.title, {color: '#FFF', marginRight: 20}]}>
            {t('MapView')}
          </Text>
        </TouchableOpacity> */}

            <ButtonForm
              label={t('save')}
              onPress={() => handleSave('SignUpViwer')}
              loading={isLoading}
              iconName="check-circle"
              iconColor="#fff"
              iconSize={25}
            />
          </View>
          {showModal && (
            <Modal
              animationIn="slideInLeft"
              animationOut="slideOutRight"
              animationInTiming={500}
              animationOutTiming={750}
              isVisible={showModal}
              useNativeDriver={true}
              onBackButtonPress={() => {
                setShowModal(!showModal);
              }}>
              <Map
                polygons={polygons}
                newPolygon={newPolygon}
                setEditing={setEditing}
                editing={editing}
                handleMapPress={handleMapPress}
                finalizePolygon={finalizePolygon}
                clearNewPolygon={clearNewPolygon}
                setShowModal={setShowModal}
                undoMark={undoMark}
                landAreaUnit={landAreaUnit}
                landUnitsquareMetre={landUnitsquareMetre}
                area={area}
                //basudev
                location={location}
                handleRegionChangeComplete={handleRegionChangeComplete}
                isLoading={isLoading}
              />
            </Modal>
          )}
        </Root>
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

export default ProduceInfoUpdate;

const styles = StyleSheet.create({
  headersContainer: {
    marginHorizontal: '5%',

    justifyContent: 'center',
    alignItems: 'center',
  },
  headersTitle: {
    paddingVertical: 5,
    // fontWeight: 'bold',
    fontSize: 18,
    color: 'white',
    fontFamily: 'Poppins-SemiBold',
  },
  mainContainer: { flex: 1, backgroundColor: 'white' },

  formContainer: {
    // backgroundColor: Colors.background, // marginTop: 30,
    // borderRadius: 8,
    // borderWidth: 1,
    // borderColor: Colors.border,
    // marginHorizontal: '4%',
    // marginBottom: 15,
    // marginTop: 10,
  },
  fromContainer: {
    flex: 1,
    backgroundColor: Colors.background,
    // paddingHorizontal: 16,
  },
  checkboxContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  firatFormContainer: {
    // marginTop: 50,

    // marginHorizontal: '4%',
    // borderWidth: 1,
    // paddingTop: 10,
    // marginBottom: 30,

    backgroundColor: 'white',
    padding: 16,
    // borderRadius: 8,
    // borderWidth: 1,
    // borderColor: Colors.border,
    // // elevation:1,

    // marginHorizontal: '4%',
  },
  // headersTitle: {
  //   fontSize: 19,
  //   fontWeight: 'bold',
  //   textAlign: 'right',
  //   marginRight: '2.5%',
  //   color: '#000',
  // },
  checkbox: {
    width: 20,
    height: 20,
    borderWidth: 2,
    borderColor: 'black',
    borderRadius: 3,
    marginRight: 8,
  },
  checked: {
    backgroundColor: 'blue',
  },
  passwordMainContainer: {
    flex: 1,
    alignItems: 'center',
  },
  passwordContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 48,
    borderWidth: 0.5,
    borderRadius: 6,
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 10,
    color: '#000000',
    //  borderColor: '#d1d5db',
    borderColor: Colors.borderGreen,
  },
  inputTextStyle: {
    flex: 1,
    height: 50,
    marginHorizontal: 10,
    borderColor: 'gray',
    fontSize: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  moreContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: '10%',
    marginVertical: '3%',
  },
  xMarkImage: {
    width: 20,
    height: 20,
  },
  moreTextContainer: {
    borderLeftWidth: 5,
    borderLeftColor: 'green',
    paddingLeft: 10,
  },
  moreText: {
    color: '#000',
    fontSize: 14,
  },
  addBtn: {
    backgroundColor: 'green',
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 10,
    color: '#FFFFFF',
    elevation: 5,
    fontFamily: 'Poppins-SemiBold',
  },
  logo: {
    width: 80,
    height: 80,
    resizeMode: 'contain',
    alignItems: 'center',
    // marginTop: 30,
    // marginBottom: 20,
    // marginLeft: 60,
  },
  text: {
    color: '#000',
  },
  loadingScreen: {
    position: 'absolute',
    top: 100,
    zIndex: 999,
    left: '40%',
  },
  text: {
    fontFamily: 'Poppins-Regular',
    color: '#000',
  },
  locationAddMoreContainer: {
    position: 'absolute',
    bottom: 125,
    right: 0,
    backgroundColor: '#025502',
    paddingVertical: 10,
    paddingLeft: 20,
    borderTopLeftRadius: 20,
    borderBottomLeftRadius: 20,
  },
  latlongContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 10,
    marginHorizontal: 5,
  },
  title: {
    color: '#000',
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
  },
  locationContainer: {
    backgroundColor: '#f6f7ffff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,

    marginTop: 10,
    borderWidth: 2,
    borderStyle: 'dotted',
    borderColor: Colors.border,
  },
  locationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  locationTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
    fontFamily: 'Poppins-Medium',
  },
  locationStatusActive: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#E8F5E9',
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 20,
  },
  locationStatusInactive: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFEBEE',
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 20,
  },
  locationStatusText: {
    marginLeft: 5,
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
    color: 'black',
  },
  coordinatesContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  coordinateItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#E3F2FD',
    padding: 8,
    borderRadius: 5,
    width: '48%',
  },
  coordinateText: {
    marginLeft: 2,
    fontSize: 12,
    color: '#0D47A1',
    fontFamily: 'Poppins-Regular',
  },
  coordinatePlaceholder: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 8,
    borderRadius: 5,
    backgroundColor: '#F5F5F5',
  },
  placeholderText: {
    fontSize: 13,
    color: '#757575',
    fontFamily: 'Poppins-Regular',
  },
  sectionTitle: {
    fontFamily: 'Poppins-Regular',
    fontSize: 15,
    color: '#4e4e4e',
    // marginBottom: 15,
  },
  labelContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    // marginBottom: -20,
    // marginLeft: 20,
    marginTop: 10,
  },
});
