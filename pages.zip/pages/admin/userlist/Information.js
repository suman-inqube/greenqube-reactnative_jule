import { StyleSheet, Text, View, ScrollView, TouchableOpacity } from 'react-native'
import React, { useState, useEffect } from 'react'
import ButtonForm from '../../Common/ButtonForm'
import InputTextForm from '../../Common/InputTextForm'
import DropdownForm from '../../Common/DropdownForm'
import RadioForm from '../../Common/RadioForm'
import ImagePlaceHolderCircle from '../../Common/ImagePlaceHolderCircle'
import { getItem } from '../../../config/getDataFromStorage'

const Information = ({ sendDataToParent, farmerID }) => {


    const [dbName, setdbName] = useState();
    const [languageData, setlanguageData] = useState([]);
    const [stateInfoData, setstateInfoData] = useState([]);
    const [districtData, setDistrictData] = useState([]);
    const [blockData, setBlockData] = useState([]);
    const [selectedImage, setSelectedImage] = useState(null);
    const [farmerData, setfarmerData] = useState({
        userName: '',
        contactNumber: '',
        gender: '',
        farmerType: '',
        age: '',
        language: '',
        stateInfo: '',
        district: '',
        block: '',
        address: '',
        zip: ''
    });


    const openImagePicker = () => {
        const options = {
            mediaType: 'photo',
            includeBase64: true,
            maxHeight: 200,
            maxWidth: 200,
        };
        launchImageLibrary(options, (response) => {
            if (response.didCancel) {
                console.log('User cancelled image picker');
            } else if (response.error) {
                console.log('Image picker error: ', response.error);
            } else {
                // let imageUri = response.uri || response.assets?.[0]?.uri;
                let imageUri = response.uri || response.assets[0].base64;
                setSelectedImage(imageUri);
            }
        });
    }

    const onPageLoad = async () => {
        const userListData = await getItem('userListData');
        if (userListData) {
            const farmerArray = userListData.rows
            const farmerFound = farmerArray.find(user => user.user_id === 'bac1b395-3468-4c94-97f6-6f4e14c3efdd');
            // const farmerFound = farmerArray.find(user => user.user_id === farmerID);
            console.log(JSON.stringify(farmerFound, null, 2))
            setfarmerData(farmerFound)
            if (farmerFound.gender == 1) {
                setfarmerData({ ...farmerData, gender: "male" })
            }
            else {
                setfarmerData({ ...farmerData, gender: "female" })
            }

            if (farmerFound.farmer_type == 1) {
                setfarmerData({ ...farmerData, farmerType: "large Grower" })
            }
            if (farmerFound.farmer_type == 2) {
                setfarmerData({ ...farmerData, farmerType: "small holder" })
            }
            else {
                setfarmerData({ ...farmerData, farmerType: "na" })
            }
        }

    };
    const sendDataToParentOnClick = () => {
        sendDataToParent(null);
    };
    useEffect(() => {
        onPageLoad();
    }, []);
    return (
        <>
            <View>
                <TouchableOpacity onPress={sendDataToParentOnClick}>
                    <Text style={{ padding: 5, backgroundColor: '#79AC78', width: 50, textAlign: 'center', color: 'white' }}>Back</Text>
                </TouchableOpacity>
            </View>
            <ScrollView style={{ backgroundColor: '#D5FFD0' }}>
                <View style={{ backgroundColor: '#D5FFD0' }}>
                    {
                        farmerData ?
                            <View style={{ paddingHorizontal: 20 }}>
                                <View style={{ alignItems: 'center' }}>
                                    <ImagePlaceHolderCircle openImagePicker={openImagePicker} selectedImage={selectedImage} />
                                </View>
                                <InputTextForm label="Name" color="red" value={farmerData.userName ?? userName} onChangeText={userName => { setfarmerData({ ...farmerData, userName: userName }) }} />

                                <InputTextForm label="contactNumber" color="red" value={farmerData.contactNumber ?? contactNumber} onChangeText={contactNumber => { setfarmerData({ ...farmerData, contactNumber: contactNumber }) }} />

                                <View>
                                    <Text style={{ fontSize: 16 }}>Gender</Text>
                                    <RadioForm
                                        label="Male"
                                        selected={farmerData.gender === 'male'}
                                        onSelect={() => setfarmerData({ ...farmerData, gender: 'male' })}
                                    />
                                    <RadioForm
                                        label="female"
                                        selected={farmerData.gender === 'female'}
                                        onSelect={() => setfarmerData({ ...farmerData, gender: 'female' })}
                                    />
                                </View>

                                <View style={{ marginBottom: 15, }}>
                                    <Text style={{ fontSize: 16, marginTop: 15, }}>User Type</Text>
                                    <RadioForm
                                        label="large Grower"
                                        selected={farmerData.userType === 'large Grower'}
                                        onSelect={() => setfarmerData({ ...farmerData, farmerType: 'large Grower' })}

                                    />
                                    <RadioForm
                                        label="Small Holder"
                                        selected={farmerData.userType === 'small holder'}
                                        onSelect={() => setfarmerData({ ...farmerData, farmerType: 'small holder' })}

                                    />
                                    <RadioForm
                                        label="na"
                                        selected={farmerData.userType === 'na'}
                                        onSelect={() => setfarmerData({ ...farmerData, farmerType: 'na' })}

                                    />
                                </View>

                                {/*
                        <InputTextForm label="Age" color="red" value={storePersnolInfo.age ?? age} onChangeText={age => { setstorePersnolInfo({ ...storePersnolInfo, age: age }) }} keyboardType="numeric" /> */}



                                {/* <DropdownForm label="State/Division/Zone" color="red" data={stateInfoData} onChange={item => { handleStateInfo(item) }} val={storePersnolInfo.stateInfo} /> */}

                                {/* <DropdownForm label="District/Country" color="red" data={districtData} onChange={item => { handleDistrict(item) }} val={storePersnolInfo.district} /> */}

                                {/* <DropdownForm label="Block/Sub Country/UpZila" color="red" data={blockData} onChange={item => { setstorePersnolInfo({ ...storePersnolInfo, block: item }) }} val={storePersnolInfo.block} /> */}

                            </View>
                            : ''
                    }

                </View>
            </ScrollView>
            <View style={{ marginTop: 10, backgroundColor: '#D5FFD0' }}>
                <ButtonForm label='Next' onPress={() => handleSave('Financial')} />
            </View>

        </>
    )
}

export default Information

const styles = StyleSheet.create({})
