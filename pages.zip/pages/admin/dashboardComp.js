import { View, Text, StyleSheet, ActivityIndicator, ScrollView, TouchableOpacity, FlatList } from 'react-native';
import ImageForm from '../Common/ImageForm';

export const BoxDisplay = ({ name, name1, imageurl }) => {
    return (
        <View style={styles.box1}>
            <View style={styles.box1_1}>
                <ImageForm
                    source={imageurl}
                    resizeMode="cover"
                    height={30}
                    width={30}
                />
            </View>
            <View>
                <Text style={styles.box1_1}>{name}</Text>
                <Text style={styles.box1_1}>{name1}</Text>
            </View>
        </View>
    );
}

export const BoxDisplaySingleLine = ({ name, imageurl }) => {
    return (
        <View style={styles.box1}>
            <View style={styles.box1_1}>
                <ImageForm
                    source={imageurl}
                    resizeMode="cover"
                    height={30}
                    width={30}
                />
            </View>
            <View>
                <Text style={styles.box1_1}>{name}</Text>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    box1:
    {
        borderRadius: 15,
        flexDirection: 'row',
        alignItems: 'center',
        height: 70,
        backgroundColor: 'white',
        shadowColor: 'rgba(0, 0, 0, 0.2)', // Shadow color (iOS)
        shadowOffset: { width: 0, height: 2 }, // Shadow offset (iOS)
        shadowOpacity: 0.8, // Shadow opacity (iOS)
        shadowRadius: 20, // Shadow radius (iOS)
    },

    box1_1: {
        marginLeft: 20,
        fontWeight: 'bold'
    }

})

