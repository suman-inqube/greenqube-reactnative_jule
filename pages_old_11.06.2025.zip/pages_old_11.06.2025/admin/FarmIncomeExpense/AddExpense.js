import { StyleSheet, Text, View, ScrollView, TextInput, FlatList, TouchableOpacity, SafeAreaView, Dimensions } from 'react-native'
import React, { useState, useEffect, useContext } from 'react'
import HeadDropDown from './HeadDropDown';
import { farmIncomeExpenceSaveAPI, farmaccountsExpenseListAPI, problemPlotAgainstFarmerAPI, problemProduceAgainstPlotAPI, } from '../../../config/apiHere';
import HarvestedModel from '../../Common/HarvestedModel';
import { userCreateContext } from '../../Context/usersCreateContext';
const AddExpense = ({ navigation }) => {
    //GQR-67
    const { loginUser_data, DropdownForm, CustomHeader, t, AlertMesg, onBackPress, getItem, logoImage, topBanner, Root, Toast, FormsTitle, InputTextForm, DatePickerComp, ButtonFormBottom, effective_dates, farmerData, } = useContext(userCreateContext);
    const { dbname, lan_id, token, user_id } = loginUser_data;
    //GQR-67
    const [currency, setcurrency] = useState("");
    const [searchResultsList, setSearchResultsList] = useState(false);
    const [searchFarmerName, setSearchFarmerName] = useState();
    const [searchFarmerPhone, setSearchFarmerPhone] = useState();
    const [searchResults, setSearchResults] = useState([]);
    const [plotAll, setplotAll] = useState([]);
    const [showingMenu, setShowingMenu] = useState(false);
    const [nameVarityStartEnd, setNameVarityStartEnd] = useState({
        name: "",
        varity: ""
    });
    const [saveData, setSaveData] = useState({
        land_rel_id: "",
        crop_name_id: "",
        sowing_date: "",
        harvesting_date: "",
        createdBy: "",
        type: "cost_production",
        plot_size: "",
        grand_total: "",
        expense_total: "",
        cost_head: ""
    });
    const [farmerID, setfarmerID] = useState();
    const [InComeAll, setInComeAll] = useState([]);
    const [isIndex, setIndex] = useState(0);
    const [data, setData] = useState([{ type: "cost_production", cat_id: "", amount: "", date: "" }]);
    const [newFromDate, setnewFromDate] = useState(new Date());
    const [openFromDate, setOpenFromDate] = useState(false);
    const [fromDate, setfromDate] = useState();
    const [modalVisible, setModalVisible] = useState(false);
    const addMoreExpense = () => {
        console.log(fromDate)
        setIndex(isIndex + 1)
        setData([...data, { type: "cost_production", cat_id: "", amount: "", date: "" }])
    }
    const handleChangeAddExpense = (index, text, name) => {
        const values = [...data];
        values[index][name] = text;
        setData(values);
    }
    const handleChangeAddCatID = (index, text, name) => {
        const values = [...data];
        values[index][name] = text.value;
        setData(values);
    }
    const handleChangeAddDate = (index, text, name) => {
        const values = [...data];
        values[index][name] = text;
        setData(values);
    }
    const handleDatePicker = (item) => {
        const effective_date = effective_dates(item);
        setfromDate(effective_date)
        handleChangeAddDate(isIndex, effective_date, "date")
        // console.log(isIndex);
    }

    // function handleClear() {
    //     setSearchFarmerName('')
    //     setSearchFarmerPhone('')
    //     setData([{ type: "cost_production", cat_id: "", amount: "", date: "" }])
    //     setplotAll([])
    //     setShowingMenu(false)
    //     setInComeAll([])
    //     setfromDate("")

    // }
    const onPageLoad = async () => {
        const curr = await getItem('currency')
        setcurrency(curr)
        // handleClear();
        // const loginUser_data = await getItem('loginUser_data');
        // if (loginUser_data) {
        //     const dbName = loginUser_data.dbname;
        //     const languageId = loginUser_data.lan_id;
        //     const token = loginUser_data.token;
        //     const supervisorId = loginUser_data.user_id;
        //     setdbLanTokUsr({
        //         ...dbLanTokUsr,
        //         dbName: dbName,
        //         languageId: languageId,
        //         token: token,
        //         supervisorId: supervisorId
        //     })
        //     const response = await farmerByNameAPI(dbName, languageId, token, supervisorId)
        //     if (response) {
        //         const dataArray = [];
        //         response.data.data.rows.forEach(element => {
        //             dataArray.push({
        //                 value: element.user_id,
        //                 label: element.userName,
        //                 phone: element.contactNumber,
        //             });
        //         });
        //         setFarmerData(dataArray)
        //     }
        // }
    };

    useEffect(() => {
        onPageLoad();
        onBackPress(() => { navigation.navigate('FarmIncomeExpenseList'); return true; })
    }, []);

    const handleResultSelect = async (name, currentfarmerId, phone) => {
        setSearchResultsList(false)
        setSearchFarmerPhone(phone)
        setSearchFarmerName(name);
        setfarmerID(currentfarmerId)
        const response = await problemPlotAgainstFarmerAPI(dbname, lan_id, token, currentfarmerId)
        if (response?.status == 200) {
            const dataArray = response.data.data.map(data => ({ value: data.rel_id, label: data.plot_no }));
            setplotAll(dataArray);
        }
    }

    const handleSearch = (text) => {
        setSearchFarmerName(text);
        setSearchFarmerPhone('');
        if (farmerData.length > 0) {
            const result = farmerData.filter(item => item.label.toLowerCase().includes(text.toLowerCase()));
            if (result) {
                setSearchResultsList(true)
                setSearchResults(result);
            }
        }
    };

    const handlePlot = async (relId) => {
        const response = await problemProduceAgainstPlotAPI(dbname, lan_id, farmerID, relId.value)
        if (response?.status == 200) {
            setNameVarityStartEnd({
                ...nameVarityStartEnd,
                name: response.data.data.rows[0].crop_name.name,
                varity: response.data.data.rows[0].crop_variety.name,
            })

            const dateString = response.data.data.rows[0].harvesting_date;
            const harvesting_date = new Date(dateString);
            const currentDate = new Date();
            if (harvesting_date > currentDate) {
                setShowingMenu(true)
                setSaveData({
                    ...saveData,
                    land_rel_id: relId.value,
                    crop_name_id: response.data.data.rows[0].crop_name_id,
                    harvesting_date: response.data.data.rows[0].harvesting_date,
                    sowing_date: response.data.data.rows[0].sowing_date,
                    plot_size: response.data.data.rows[0].land_info.land_size + " " + response.data.data.rows[0].land_info.land_unit.name,
                    createdBy: user_id,
                })
                const response_farmIncome = await farmaccountsExpenseListAPI(dbname, lan_id, farmerID)
                if (response_farmIncome?.status == 200) {
                    const dataArray = response_farmIncome?.data?.data?.rows.map(data => ({ value: data.fid, label: data.categoryName, }))
                    setInComeAll(dataArray);
                }
            } else {
                setModalVisible(true);
                setSearchFarmerName('')
                setSearchFarmerPhone('')
                setplotAll([])
            }
        }
    }

    const handleSave = async () => {
        if (saveData.crop_name_id == "") {
            Toast.show({ time: 2, text: `${t('please_enter_farmer_name')}`, ...AlertMesg[0] });
        } else if (saveData.land_rel_id == "") {
            Toast.show({ time: 2, text: `${t('please_enter_plot_name_first')}`, ...AlertMesg[0] });
        } else {
            let expense_total = 0
            data.forEach(element => {
                expense_total += parseInt(element.amount)
            });
            const qs = require('qs');
            let save_data = qs.stringify({
                'land_rel_id': saveData.land_rel_id,
                'crop_name_id': saveData.crop_name_id,
                'harvesting_date': saveData.harvesting_date.substring(0, 10),
                'sowing_date': saveData.sowing_date,
                'createdBy': saveData.createdBy,
                'type': 'cost_production',
                'plot_size': saveData.plot_size,
                'grand_total': "0",
                'expense_total': expense_total,
                'cost_head': JSON.stringify(data)
            });
            const response = await farmIncomeExpenceSaveAPI(dbname, lan_id, token, farmerID, save_data);
            if (response?.status == 200) {
                navigation.navigate('FarmIncomeExpenseList');
            }
        }
    }
    const HandlerGoBack = () => navigation.navigate('FarmIncomeExpenseList');
    const handleHarvested = async (data) => {
        if (data == 'Yes') {
            navigation.navigate('FarmIncomeExpenseList');
        } else {
            navigation.navigate('Dashboard');
        }
    }
    return (
        <Root>
            <View style={{ flex: 1 }}>
                <DatePickerComp
                    openDate={openFromDate}
                    newDate={newFromDate}
                    setOpenDate={setOpenFromDate}
                    handleDatePicker={handleDatePicker}
                />
                <CustomHeader path='FarmIncomeExpenseList' HandlerGoBack={HandlerGoBack} logoImage={logoImage} topBanner={topBanner} />
                <FormsTitle title={t('add_expense')} />
                <SafeAreaView>
                    {
                        searchResultsList && searchResultsList ?
                            <View style={styles.flatContainer}>
                                <FlatList
                                    style={searchResults.length > 8 ? styles.flatlistHeight : ""}
                                    data={searchResults}
                                    renderItem={({ item }) => (
                                        <TouchableOpacity onPress={() => handleResultSelect(item.label, item.value, item.phone)} style={styles.flatlistitem}>
                                            <Text style={styles.flatlisttitle}>{item.label}</Text>
                                        </TouchableOpacity>
                                    )}
                                    keyExtractor={(item, index) => index}
                                />
                            </View> : ""
                    }
                </SafeAreaView>
                {modalVisible && <HarvestedModel setModalVisible={setModalVisible} modalVisible={modalVisible} handleHarvested={handleHarvested} />}
                <View style={styles.formContainer}>
                    <ScrollView showsVerticalScrollIndicator={false}>
                        <InputTextForm label={t('farmer_name')} value={searchFarmerName}
                            onChangeText={(farmerName) => handleSearch(farmerName)} />
                        <InputTextForm label={t('farmer_number')} value={searchFarmerPhone} />
                        <DropdownForm label={t('plot')} data={plotAll} color="red" onChange={relId => handlePlot(relId)} />
                        {
                            showingMenu
                                ?
                                <View style={styles.plotContainer}>
                                    <View style={styles.plotItem}>
                                        <Text style={styles.plotItemText}>{t('produce_name')}</Text>
                                        <Text style={styles.plotItemText}>{t('prodece_vareity')}</Text>
                                    </View>
                                    <View style={styles.plotItem} >
                                        <Text style={styles.plotItemText}>{nameVarityStartEnd.name}</Text>
                                        <Text style={styles.plotItemText}>{nameVarityStartEnd.varity}</Text>
                                    </View>
                                </View>
                                :
                                ''

                        }

                        <View style={{ marginBottom: 350 }}>
                            {
                                data.map((data, index) => {
                                    return (
                                        <View style={styles.AddExpenseContainer} key={index}>
                                            <View>
                                                <TextInput
                                                    style={styles.AddExpenseInput}
                                                    onChangeText={(text) => handleChangeAddExpense(index, text, 'amount')}
                                                    name='amount'
                                                    placeholder={t('amount') + "(" + currency + ")"}
                                                    keyboardType="numeric"
                                                    placeholderTextColor={'#000'}
                                                    value={data.amount}
                                                />
                                            </View>
                                            <View style={styles.AddExpenseItemContainer}>
                                                <View style={styles.AddExpenseItem}>
                                                    <HeadDropDown label={t('add_income_head')} data={InComeAll} name='cat_id' onChange={(text) => handleChangeAddCatID(index, text, 'cat_id')} />
                                                </View>
                                                <TouchableOpacity onPress={() => setOpenFromDate(true)}
                                                    style={styles.AddExpenseItemDate}>
                                                    <Text style={styles.title}>{data.date == "" ? `${t('date')}` : data.date}</Text>
                                                </TouchableOpacity>
                                            </View>
                                        </View>
                                    )
                                })
                            }
                        </View>

                    </ScrollView>
                    <TouchableOpacity onPress={addMoreExpense} style={styles.addMore}>
                        <Text style={styles.addMoreText} >{t('add_more')}</Text>
                    </TouchableOpacity>
                </View>
                <ButtonFormBottom label='Submit' onPress={() => handleSave()} />
            </View>
        </Root>
    )
}

export default AddExpense

const styles = StyleSheet.create({
    formContainer: {
        width: '90%',
        marginHorizontal: '5%',
    },
    AddExpenseContainer: {
        borderWidth: 1,
        marginVertical: 10,
        padding: 10,
        borderRadius: 10,
        borderColor: '#000',
        backgroundColor: '#FFF'
    },
    AddExpenseInput: {
        borderWidth: 1,
        borderColor: '#000',
        borderRadius: 10,
        marginVertical: 10,
        // fontSize: 25,
        color: '#000',
        fontFamily: 'Poppins-Regular',
        fontSize: 18,
    },
    AddExpenseItemContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        width: '100%',
    },
    AddExpenseItem: {
        width: '60%',
        marginTop: 12
    },
    AddExpenseItemDate: {
        width: '30%',
        borderWidth: 1,
        padding: 8,
        borderRadius: 10
    },
    addMore: {
        position: 'absolute',
        right: '-6%',
        // bottom: 0,
        top: "55%",
        zIndex: 999,
        backgroundColor: 'green',
        // width: 100,
        padding: 10,
        borderTopLeftRadius: 30,
        borderBottomLeftRadius: 30,
    },
    addMoreText: {
        color: '#FFF',
        textAlign: 'center',
        fontFamily: 'Poppins-Regular',
        fontSize: 14
    },
    plotContainer: {
        flexDirection: 'row',
        borderWidth: 1,
        borderColor: '#000',
        padding: 10,
        borderRadius: 10,
        backgroundColor: '#FFF'
    },
    plotItem: {
        width: '50%'
    },
    plotItemText: {
        color: '#000',
        marginVertical: 5,
        fontFamily: 'Poppins-Regular',
        fontSize: 14
    },
    flatContainer: {
        backgroundColor: '#ffffff',
        position: 'absolute',
        zIndex: 999,
        // bottom: '100%',
        top: 90,
        left: 0,
        marginHorizontal: '5%',
        width: '90%',
        elevation: 10,
        borderRadius: 10,
        padding: 10
    },

    flatlisttitle: {
        padding: 10,
        color: '#000',
        fontFamily: 'Poppins-Regular',
        fontSize: 14
    },

    flatlistHeight: {
        height: Dimensions.get('window').height / 3.2
    },
    title: {
        color: '#000',
        fontFamily: 'Poppins-Regular',
        fontSize: 14
    }
})