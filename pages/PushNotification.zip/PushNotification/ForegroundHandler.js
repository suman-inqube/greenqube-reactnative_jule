import PushNotificationIOS from '@react-native-community/push-notification-ios';
import React, { useEffect } from 'react';
import messaging from '@react-native-firebase/messaging';
import { Platform, Alert } from 'react-native';
import PushNotification from "react-native-push-notification";
import { useNavigation } from '@react-navigation/native';
const ForegroundHandler = () => {
    const navigation = useNavigation();
    const setupPushNotification = (handleNotification) => {
        PushNotification.configure({
            onNotification: function (notification) {
                handleNotification(notification)
            },
            popInitialNotification: true,
            requestPermissions: true,
        })
        return PushNotification
    }
    _handleNotificationOpen = () => {
        // navigation.navigate("ProblemList")
    }
    useEffect(() => {
        setupPushNotification(_handleNotificationOpen)
        const unsubscribe = messaging().onMessage((remoteMessage) => {
            console.log("handle in foreground", remoteMessage)
            const { notification, messageId } = remoteMessage
            if (Platform.OS == 'ios') {
                PushNotificationIOS.addNotificationRequest({
                    id: messageId,
                    body: notification.body,
                    title: notification.title,
                    sound: 'default'
                });
            } else {
                // Alert.alert('A new FCM message arrived!', JSON.stringify(remoteMessage));
                PushNotification.configure({
                    onNotification: function (notification) {
                        // Handle notification tap
                        if (notification.userInteraction) {
                            // Extract route information from notification payload
                            const route = notification.data.route;
                            // Navigate to the specified route
                            // This assumes you have set up navigation using React Navigation
                            navigation.navigate("ProblemList");
                        }
                    },
                });
            }
        })
        return unsubscribe
    }, [])
    return null
}

export default ForegroundHandler