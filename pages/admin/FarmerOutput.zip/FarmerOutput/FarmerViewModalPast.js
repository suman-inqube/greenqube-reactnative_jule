import { StyleSheet, Text, View, Modal, TouchableOpacity } from 'react-native'
import React from 'react'
import { formatDateToMMDDYYYY } from '../../Common/DateChanger';
import { useTranslation } from 'react-i18next';

const FarmerViewModalPast = (props) => {
    const { t } = useTranslation();
    return (
        <View>
            <Modal
                animationType="slide"
                transparent={true}
                visible={props.modalVisible}
                onRequestClose={() => {
                    
                    props.setModalVisible(!props.modalVisible);
                }}
            >
                <TouchableOpacity style={[styles.container, props.style]} activeOpacity={1} onPress={() => props.setModalVisible(!props.modalVisible)}  >
                    <View style={styles.modalView}>
                        <View style={styles.modelTitleContainer}>
                            {
                                
                                props.outputSingle ?
                                    <View style={styles.itemContainer}>
                                        {
                                            props.outputSingle.others ?
                                                

                                                <View style={styles.item}>
                                                    <Text style={styles.itemText}>{t('name')}</Text>
                                                    <Text style={styles.itemText}>: {props.outputSingle.others}</Text>
                                                </View>
                                                :
                                                <>
                                                    <View style={styles.item}>
                                                        <Text style={styles.itemText}>{t('agent_crop_problem_plot')}</Text>
                                                        <Text style={styles.itemText}>: {props.outputSingle.inout_plot_rel && props.outputSingle.inout_plot_rel.plot_no}</Text>
                                                    </View>
                                                    <View style={styles.item}>
                                                        <Text style={styles.itemText}>{t('crop_name')}</Text>
                                                        <Text style={styles.itemText}>: {props.outputSingle.io_crop_name && props.outputSingle.io_crop_name.name}</Text>
                                                    </View>
                                                    <View style={styles.item}>
                                                        <Text style={styles.itemText}>{t('crop_veriety')}</Text>
                                                        <Text style={styles.itemText}>: {props.outputSingle.io_crop_variety && props.outputSingle.io_crop_variety.name}</Text>
                                                    </View>
                                                </>
                                        }
                                        <>
                                            <View style={styles.item}>
                                                <Text style={styles.itemText}>{t('qty_amp_unit')}</Text>
                                                <Text style={styles.itemText}>: {props.outputSingle.quantity && props.outputSingle.quantity}   {props.outputSingle.unit_id && props.outputSingle.unit_id}</Text>
                                            </View>

                                            <View style={styles.item}>
                                                <Text style={styles.itemText}>{t('farmer_name')}</Text>
                                                <Text style={styles.itemText}>: {props.outputSingle.users && props.outputSingle.users.userName}</Text>
                                            </View>
                                            <View style={styles.item}>
                                                <Text style={styles.itemText}>{t('farmer_number')}</Text>
                                                <Text style={styles.itemText}>: {props.outputSingle.users && props.outputSingle.users.contactNumber}</Text>
                                            </View>
                                            <View style={styles.item}>
                                                <Text style={styles.itemText}>{t('required_date')}</Text>
                                                <Text style={styles.itemText}>: {formatDateToMMDDYYYY(props.outputSingle.date)}</Text>
                                            </View>

                                        </>




                                    </View>
                                    : ''
                            }

                        </View>
                    </View>
                </TouchableOpacity>
            </Modal>
        </View>
    )
}

export default FarmerViewModalPast

const styles = StyleSheet.create({
    container: {

    },
    modalView: {
        backgroundColor: '#FFF',
        width: '90%',
        borderRadius: 10
    },
    modelTitleContainer: {
        backgroundColor: '#165A2B',
        width: '95%',
        margin: '2.5%',
        borderRadius: 10
    },
    itemContainer: {

    },
    item: {
        flexDirection: 'row',
        marginHorizontal: 10,
        marginVertical: 5,
        alignItems: 'center'
    },
    itemText: {
        width: '50%',
        color: '#FFF'
    },
    line: {
        backgroundColor: '#FFF',
        height: 3,
        marginHorizontal: 3,
        borderRadius: 10
    }
})