import BackgroundService from 'react-native-background-actions';
import FusedLocation from 'react-native-fused-location';
import { Linking, Alert } from 'react-native';
import { useState, useEffect } from 'react';
import { useIsFocused } from '@react-navigation/native';
const sleep = (time) => new Promise((resolve) => setTimeout(() => resolve(), time));
const BackGroundLocation = () => {
    const isFocused = useIsFocused();
    useEffect(() => {
        console.log(isFocused);
    }, [isFocused])
    const [currentlatlongData, setCurrentlatlongData] = useState({
        lat: "", long: ""
    })
    const options = {
        taskName: 'GPS',
        taskTitle: 'GPS',
        taskDesc: 'GPS',
        taskIcon: {
            name: 'ic_launcher',
            type: 'mipmap',
        },
        color: '#ff00ff',
        linkingURI: 'yourSchemeHere://chat/jane', // See Deep Linking for more info
        parameters: {
            delay: 4000,
        },
        indeterminate: false
    };
    const veryIntensiveTask = async (taskDataArguments) => {
        const { delay } = taskDataArguments;
        await new Promise(async (resolve) => {
            for (let i = 0; BackgroundService.isRunning(); i++) {
                // console.log(i);
                try {
                    const location = await FusedLocation.getFusedLocation();
                    const { latitude, longitude } = location;
                    setCurrentlatlongData({ ...currentlatlongData, lat: latitude, long: longitude })
                } catch (error) {
                    // Alert.alert("GreenQube",
                    //     "Your GPS seems to be disabled, do you want to enable it?",
                    //     [
                    //         { text: 'Yes', onPress: this._doSomethingSerious, style: 'destructive' },
                    //         { text: 'No' },
                    //     ],
                    //     { cancelable: false }
                    // )
                    // Linking.sendIntent('android.settings.LOCATION_SOURCE_SETTINGS');
                    console.log("error")
                }
                await sleep(delay);
            }
        });
    };
    const getCurrentLatLong = async () => {
        await BackgroundService.start(veryIntensiveTask, options);
    }
    return {
        getCurrentLatLong,
        currentlatlongData
    };
}
export default BackGroundLocation

