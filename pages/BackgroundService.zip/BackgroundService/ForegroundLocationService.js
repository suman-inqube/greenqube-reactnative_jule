import React, { useEffect, useState } from 'react';
import { Platform, Alert, Linking } from 'react-native';
import FusedLocation from 'react-native-fused-location';
import store from '../redux/store';
import { updateLocation } from '../redux/actions/locationActions';
import { check, PERMISSIONS, RESULTS } from '@react-native-community/permissions';
const ForegroundLocationService = () => {
    useEffect(() => {
        const showAlertMsg = () => {
            Alert.alert("GreenQube",
                "Your GPS seems to be disabled, do you want to enable it?",
                [
                    { text: 'Yes', onPress: () => Linking.sendIntent('android.settings.LOCATION_SOURCE_SETTINGS'), style: 'destructive' },
                    { text: 'No' },
                ],
                { cancelable: false }
            )
        }
        const startLocationUpdates = async () => {
            try {
                FusedLocation.setLocationPriority(FusedLocation.Constants.HIGH_ACCURACY);
                FusedLocation.setLocationInterval(2000);
                FusedLocation.setFastestLocationInterval(3000);
                FusedLocation.startLocationUpdates();
                const subscription = FusedLocation.on('fusedLocation', location => {
                    store.dispatch(updateLocation(location));
                });
                return () => {
                    subscription.remove();
                    FusedLocation.stopLocationUpdates();
                };
            } catch (error) {
                console.log(error)
            }
        };
        startLocationUpdates();
    }, []);
    // return null; // This component doesn't render anything
    return null

};
export default ForegroundLocationService;
